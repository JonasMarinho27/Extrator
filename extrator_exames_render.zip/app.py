
from flask import Flask, request, render_template, jsonify
import pytesseract
import pdfplumber
from PIL import Image
import re

app = Flask(__name__)

# Lista básica de parâmetros clínicos
PARAMETROS = [
    "hemoglobina", "hematócrito", "leucócitos", "plaquetas", "ureia", "creatinina",
    "tgo", "tgp", "gama gt", "bilirrubina", "glicose", "colesterol", "triglicerídeos"
]

# Expressão regular base para pegar números com vírgula ou ponto
def extrair_parametros(texto):
    resultados = []
    texto = texto.lower()
    for parametro in PARAMETROS:
        padrao = rf"{parametro}.*?(\d+[\.,]\d+)"
        match = re.search(padrao, texto)
        if match:
            valor = match.group(1).replace(',', '.')
            resultados.append(f"{parametro.capitalize()} {valor}")
    return " // ".join(resultados)

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']
    texto = ""

    if file.filename.endswith('.pdf'):
        with pdfplumber.open(file) as pdf:
            for page in pdf.pages:
                texto += page.extract_text() + "\n"
    else:
        image = Image.open(file.stream)
        texto = pytesseract.image_to_string(image, lang='por')

    resultado = extrair_parametros(texto)
    return jsonify({"resultado": resultado})

import os

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
